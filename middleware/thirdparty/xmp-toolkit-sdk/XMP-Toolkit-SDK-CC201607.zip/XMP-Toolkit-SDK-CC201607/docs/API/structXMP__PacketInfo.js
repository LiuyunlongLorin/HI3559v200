var structXMP__PacketInfo =
[
    [ "XMP_PacketInfo", "structXMP__PacketInfo.html#a2ae03a1b3d03fa9ebc829105037155a8", null ],
    [ "charForm", "structXMP__PacketInfo.html#a039ce6665fe8e08d922a46f266799f75", null ],
    [ "hasWrapper", "structXMP__PacketInfo.html#a6725d8ab8b4eedddaac950d2b1b00a7f", null ],
    [ "length", "structXMP__PacketInfo.html#af526c582b66e24553f2d4b11eb714a44", null ],
    [ "offset", "structXMP__PacketInfo.html#a20f65fcfd0f3658ab93ff441a9d61d2c", null ],
    [ "pad", "structXMP__PacketInfo.html#a83ec12161a36451fef05d88cc754104e", null ],
    [ "padSize", "structXMP__PacketInfo.html#af4f99e6a5b36b05fdf4a519421875256", null ],
    [ "writeable", "structXMP__PacketInfo.html#a66845c1d5f3f9f36a1543a7322bd7bd1", null ]
];