var classAdobeXMPCore_1_1ISimpleNode__v1 =
[
    [ "~ISimpleNode_v1", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a12de1bae1dcb7c8302044df2b4fddb02", null ],
    [ "CreateSimpleNode", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a9221d195ce7d207b65652008666e04d6", null ],
    [ "GetValue", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a92d0fc99b2af5ef28027e693f9b37964", null ],
    [ "IsURIType", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a6164e2541b1245d43f1e21b94f75e20c", null ],
    [ "SetURIType", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a8781cf6bb583b419cf5fcaf6cf311bd2", null ],
    [ "SetValue", "classAdobeXMPCore_1_1ISimpleNode__v1.html#a0391485cf8c432ba03874d4329c5510e", null ]
];