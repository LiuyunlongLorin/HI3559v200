var classAdobeXMPCore_1_1IDOMParser__v1 =
[
    [ "eActionType", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345", [
      [ "kATAppendAsChildren", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345a6ce0fb64b1a284951f50aacdf76e28b9", null ],
      [ "kATReplaceChildren", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345ac19566553b38e9bf6c5361a8aa9bb181", null ],
      [ "kATAppendOrReplaceChildren", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345a720d171caeb649caf22e27ed4a39bd15", null ],
      [ "kATInsertBefore", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345aabbc604d77794e6cecedf1bdd947d252", null ],
      [ "kATInsertAfter", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345a8fca6913cbd9d4f787e53fdcfb54f2bf", null ],
      [ "kATReplace", "classAdobeXMPCore_1_1IDOMParser__v1.html#a9f311215532a5fa1d15a491fc7e71345a2adb910039a572f5e73dbb94f680ed18", null ]
    ] ],
    [ "~IDOMParser_v1", "classAdobeXMPCore_1_1IDOMParser__v1.html#a8cbde9bf86ebb4ef4a6968e39b601670", null ],
    [ "Clone", "classAdobeXMPCore_1_1IDOMParser__v1.html#a0d771fa042d5c5b3cf015f567f8aea9f", null ],
    [ "Parse", "classAdobeXMPCore_1_1IDOMParser__v1.html#adc690f22fbc146bebb91366de7a8739e", null ],
    [ "ParseWithSpecificAction", "classAdobeXMPCore_1_1IDOMParser__v1.html#ad57596496a555684497ea918569df7d2", null ]
];