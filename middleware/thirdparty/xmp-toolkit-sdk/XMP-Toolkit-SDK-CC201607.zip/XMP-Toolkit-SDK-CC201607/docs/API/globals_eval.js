var globals_eval =
[
    [ "_", "globals_eval.html", null ],
    [ "k", "globals_eval_k.html", null ]
];