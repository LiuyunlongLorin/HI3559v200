var namespaceAdobeXMPCore =
[
    [ "IArrayNode_v1", "classAdobeXMPCore_1_1IArrayNode__v1.html", "classAdobeXMPCore_1_1IArrayNode__v1" ],
    [ "IClientDOMParser_v1", "classAdobeXMPCore_1_1IClientDOMParser__v1.html", "classAdobeXMPCore_1_1IClientDOMParser__v1" ],
    [ "IClientDOMSerializer_v1", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html", "classAdobeXMPCore_1_1IClientDOMSerializer__v1" ],
    [ "ICompositeNode_v1", "classAdobeXMPCore_1_1ICompositeNode__v1.html", "classAdobeXMPCore_1_1ICompositeNode__v1" ],
    [ "ICoreConfigurationManager_v1", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1.html", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1" ],
    [ "ICoreObjectFactory_v1", "classAdobeXMPCore_1_1ICoreObjectFactory__v1.html", "classAdobeXMPCore_1_1ICoreObjectFactory__v1" ],
    [ "IDOMImplementationRegistry_v1", "classAdobeXMPCore_1_1IDOMImplementationRegistry__v1.html", "classAdobeXMPCore_1_1IDOMImplementationRegistry__v1" ],
    [ "IDOMParser_v1", "classAdobeXMPCore_1_1IDOMParser__v1.html", "classAdobeXMPCore_1_1IDOMParser__v1" ],
    [ "IDOMSerializer_v1", "classAdobeXMPCore_1_1IDOMSerializer__v1.html", "classAdobeXMPCore_1_1IDOMSerializer__v1" ],
    [ "IMetadata_v1", "classAdobeXMPCore_1_1IMetadata__v1.html", "classAdobeXMPCore_1_1IMetadata__v1" ],
    [ "INameSpacePrefixMap_v1", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1" ],
    [ "INode_v1", "classAdobeXMPCore_1_1INode__v1.html", "classAdobeXMPCore_1_1INode__v1" ],
    [ "INodeIterator_v1", "classAdobeXMPCore_1_1INodeIterator__v1.html", "classAdobeXMPCore_1_1INodeIterator__v1" ],
    [ "IPath_v1", "classAdobeXMPCore_1_1IPath__v1.html", "classAdobeXMPCore_1_1IPath__v1" ],
    [ "IPathSegment_v1", "classAdobeXMPCore_1_1IPathSegment__v1.html", "classAdobeXMPCore_1_1IPathSegment__v1" ],
    [ "ISimpleNode_v1", "classAdobeXMPCore_1_1ISimpleNode__v1.html", "classAdobeXMPCore_1_1ISimpleNode__v1" ],
    [ "IStructureNode_v1", "classAdobeXMPCore_1_1IStructureNode__v1.html", "classAdobeXMPCore_1_1IStructureNode__v1" ]
];