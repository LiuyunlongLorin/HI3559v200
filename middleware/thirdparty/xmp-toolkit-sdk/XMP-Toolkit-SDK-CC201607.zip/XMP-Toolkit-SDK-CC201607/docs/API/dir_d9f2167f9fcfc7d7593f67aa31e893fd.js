var dir_d9f2167f9fcfc7d7593f67aa31e893fd =
[
    [ "Interfaces", "dir_8223d5ea7844a33492dce354418ea45e.html", "dir_8223d5ea7844a33492dce354418ea45e" ],
    [ "XMPCoreDefines.h", "XMPCoreDefines_8h.html", "XMPCoreDefines_8h" ],
    [ "XMPCoreErrorCodes.h", "XMPCoreErrorCodes_8h.html", "XMPCoreErrorCodes_8h" ],
    [ "XMPCoreFwdDeclarations.h", "XMPCoreFwdDeclarations_8h.html", "XMPCoreFwdDeclarations_8h" ],
    [ "XMPCoreLatestInterfaceVersions.h", "XMPCoreLatestInterfaceVersions_8h.html", "XMPCoreLatestInterfaceVersions_8h" ]
];