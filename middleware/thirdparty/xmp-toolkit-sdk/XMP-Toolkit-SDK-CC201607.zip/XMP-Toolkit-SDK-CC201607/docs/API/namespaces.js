var namespaces =
[
    [ "AdobeXMPCommon", "namespaceAdobeXMPCommon.html", null ],
    [ "AdobeXMPCommon_Int", "namespaceAdobeXMPCommon__Int.html", null ],
    [ "AdobeXMPCore", "namespaceAdobeXMPCore.html", null ],
    [ "AdobeXMPCore_Int", "namespaceAdobeXMPCore__Int.html", null ]
];