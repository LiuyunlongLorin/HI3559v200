var classAdobeXMPCore_1_1IArrayNode__v1 =
[
    [ "eArrayForm", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3", [
      [ "kAFNone", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3a9e94ffd1d41fc1770ea2430ddb6b0850", null ],
      [ "kAFUnordered", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3afbd5e7a5cc72cd12eeec6e4ab370b29c", null ],
      [ "kAFOrdered", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3ae739b09d3ac25faa60551f181c273163", null ],
      [ "kAFAlternative", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3a76f68496b69df8d9ff018d0eb7cf214c", null ],
      [ "kAFAll", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7b5b5daa606aeb28496f326ac705a9a3a7dd5034acb7178341218ab2389bb45cf", null ]
    ] ],
    [ "~IArrayNode_v1", "classAdobeXMPCore_1_1IArrayNode__v1.html#ae72a477964eaa0590d7ee415e044bc02", null ],
    [ "CreateAlternativeArrayNode", "classAdobeXMPCore_1_1IArrayNode__v1.html#afcb8012075f5c956139bff39f41bae47", null ],
    [ "CreateOrderedArrayNode", "classAdobeXMPCore_1_1IArrayNode__v1.html#a6e9068b8048a29804fb9d567c6cc8952", null ],
    [ "CreateUnorderedArrayNode", "classAdobeXMPCore_1_1IArrayNode__v1.html#a9b89618c3115efc948bd7fb49dfc570c", null ],
    [ "GetArrayForm", "classAdobeXMPCore_1_1IArrayNode__v1.html#ae75dc043c5da4ab09b4700fcbfc065ec", null ],
    [ "GetArrayNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#a57011f7b4cf194ef1a2e52011671b862", null ],
    [ "GetArrayNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#ac16b0614e51f8323585d653c0d36faf2", null ],
    [ "GetChildNodeType", "classAdobeXMPCore_1_1IArrayNode__v1.html#ad3748958964789cb3d20d5776b1157b5", null ],
    [ "GetNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#a7c2e3c217f7e1bb28504c40da474f01e", null ],
    [ "GetNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#ae3bf9368ff5fa36665e21911bbab98b5", null ],
    [ "GetSimpleNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#ab6cffa23c82a1dee98d634e8b4081510", null ],
    [ "GetSimpleNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#a37ba080075f5158ffdffbb36437e2622", null ],
    [ "GetStructureNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#aabcee273a5efdaf57975f52f11ba8e85", null ],
    [ "GetStructureNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#aaf0ef3b97a41d1035f789dc3ab127bae", null ],
    [ "InsertNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#af206a6ae16faa9083b0c80b0becccde2", null ],
    [ "RemoveNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#a435be63553b76b568fc8a6f980f4eac6", null ],
    [ "ReplaceNodeAtIndex", "classAdobeXMPCore_1_1IArrayNode__v1.html#a484e351f788771cf4500bfe0a2b144ec", null ]
];