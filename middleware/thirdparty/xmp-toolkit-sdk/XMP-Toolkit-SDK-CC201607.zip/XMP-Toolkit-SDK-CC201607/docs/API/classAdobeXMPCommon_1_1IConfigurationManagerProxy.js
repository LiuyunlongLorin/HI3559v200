var classAdobeXMPCommon_1_1IConfigurationManagerProxy =
[
    [ "IConfigurationManagerProxy", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#aa6e0ad02dd491d0881e35ea0554c93a6", null ],
    [ "~IConfigurationManagerProxy", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a2d3924186af26ed2ea955d155ba8e89c", null ],
    [ "Acquire", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#ab368f307d6f23590d7ee76974cbd87fa", null ],
    [ "DisableMultiThreading", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a8432b3ab3d3e1c344dc006308e34e4bc", null ],
    [ "disableMultiThreading", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a9d07fe612bdc448ea279f9c6a8f2c905", null ],
    [ "GetActualIConfigurationManager", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a51a9e283ecad4043182f5ff9c8c38367", null ],
    [ "GetInterfacePointer", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#acf184689e6c9862642425392ac80640c", null ],
    [ "getInterfacePointer", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#acb62caf44deca15cc1a427ff4d437e0b", null ],
    [ "GetISharedObject_I", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a9efc36a9faf07297c329f1c422659758", null ],
    [ "IsMultiThreaded", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a84324c2d73c81094f9a4ea365b22acb7", null ],
    [ "isMultiThreaded", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a7b99c9d6b1b337c74b240afbdb1ba11a", null ],
    [ "RegisterErrorNotifier", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a2f95a01a640809db056c50f3af9969a3", null ],
    [ "registerErrorNotifier", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#adec0b71edd5e1d6af91ddb57d4c46fe5", null ],
    [ "RegisterMemoryAllocator", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a1cd3f0ed28518a855a9adec183f638c5", null ],
    [ "registerMemoryAllocator", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#aecb05f0b0c1c934c00aab318d6de1daf", null ],
    [ "Release", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#ad53bcc0d6f8a1978b43a007c040c4c04", null ],
    [ "mRawPtr", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html#a57ee5dce3f7d579adb79ebc00618aa17", null ]
];