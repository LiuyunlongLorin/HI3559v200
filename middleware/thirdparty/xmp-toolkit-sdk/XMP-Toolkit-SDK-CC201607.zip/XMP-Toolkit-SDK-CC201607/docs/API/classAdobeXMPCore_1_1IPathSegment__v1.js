var classAdobeXMPCore_1_1IPathSegment__v1 =
[
    [ "ePathSegmentType", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9", [
      [ "kPSTNone", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9ab178c4df00dc4b10c7c5937d82499a84", null ],
      [ "kPSTProperty", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9ac351f884bf338c15a4a619e89216e2b9", null ],
      [ "kPSTArrayIndex", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9ae86feb38a46c4fb2ecb35bb651dca161", null ],
      [ "kPSTQualifier", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9a8d1e54d4a1f97847f03eb7ff36c263a7", null ],
      [ "kPSTQualifierSelector", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9a2eb4a4d89f26c720eb393eb56997ba09", null ],
      [ "kPSTAll", "classAdobeXMPCore_1_1IPathSegment__v1.html#a8a9f850adf6f3f510298df13896b76b9a6c99b2ecc364a71db39b2e9ff0a94880", null ]
    ] ],
    [ "~IPathSegment_v1", "classAdobeXMPCore_1_1IPathSegment__v1.html#a1ef63ec40233a30d4ec9f165e5332a43", null ],
    [ "CreateArrayIndexPathSegment", "classAdobeXMPCore_1_1IPathSegment__v1.html#ab94dc022fdf9edad3423c8f281f95674", null ],
    [ "CreatePropertyPathSegment", "classAdobeXMPCore_1_1IPathSegment__v1.html#a78df7478295fed763eadac0cefb79e1b", null ],
    [ "CreateQualifierPathSegment", "classAdobeXMPCore_1_1IPathSegment__v1.html#a49da0c0bed14c7afb07d263570f09221", null ],
    [ "CreateQualifierSelectorPathSegment", "classAdobeXMPCore_1_1IPathSegment__v1.html#a854506c44a7acfc0246709a6cd74638d", null ],
    [ "GetIndex", "classAdobeXMPCore_1_1IPathSegment__v1.html#a6552774db8039b1ddc02491fc82b2699", null ],
    [ "GetName", "classAdobeXMPCore_1_1IPathSegment__v1.html#a9c7e02cccca4d74467483ab442871376", null ],
    [ "GetNameSpace", "classAdobeXMPCore_1_1IPathSegment__v1.html#ae6726749b73c1c99caa05e65138f9a64", null ],
    [ "GetType", "classAdobeXMPCore_1_1IPathSegment__v1.html#a0febe9ac58c1a2a3e0a573f1bb9c25c3", null ],
    [ "GetValue", "classAdobeXMPCore_1_1IPathSegment__v1.html#abc957b6cdedc2b4feb8943b42d2d3fe9", null ]
];