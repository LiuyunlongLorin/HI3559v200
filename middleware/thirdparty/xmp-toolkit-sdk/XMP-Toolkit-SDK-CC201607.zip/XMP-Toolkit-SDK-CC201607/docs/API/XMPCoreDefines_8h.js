var XMPCoreDefines_8h =
[
    [ "ENABLE_CPP_DOM_MODEL", "XMPCoreDefines_8h.html#a6919ea0ee288c12c640a170d34d35cbe", null ]
];