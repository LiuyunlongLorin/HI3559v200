var annotated_dup =
[
    [ "AdobeXMPCommon", "namespaceAdobeXMPCommon.html", "namespaceAdobeXMPCommon" ],
    [ "AdobeXMPCore", "namespaceAdobeXMPCore.html", "namespaceAdobeXMPCore" ],
    [ "TXMPFiles", "classTXMPFiles.html", "classTXMPFiles" ],
    [ "TXMPIterator", "classTXMPIterator.html", "classTXMPIterator" ],
    [ "TXMPMeta", "classTXMPMeta.html", "classTXMPMeta" ],
    [ "TXMPUtils", "classTXMPUtils.html", "classTXMPUtils" ],
    [ "WXMP_Result", "structWXMP__Result.html", "structWXMP__Result" ],
    [ "XMP_DateTime", "structXMP__DateTime.html", "structXMP__DateTime" ],
    [ "XMP_Error", "classXMP__Error.html", "classXMP__Error" ],
    [ "XMP_IO", "classXMP__IO.html", "classXMP__IO" ],
    [ "XMP_PacketInfo", "structXMP__PacketInfo.html", "structXMP__PacketInfo" ],
    [ "XMP_VersionInfo", "structXMP__VersionInfo.html", "structXMP__VersionInfo" ]
];