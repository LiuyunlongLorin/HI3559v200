var namespaceAdobeXMPCommon =
[
    [ "IConfigurable", "classAdobeXMPCommon_1_1IConfigurable.html", "classAdobeXMPCommon_1_1IConfigurable" ],
    [ "IConfigurationManager_v1", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html", "classAdobeXMPCommon_1_1IConfigurationManager__v1" ],
    [ "IConfigurationManagerProxy", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html", "classAdobeXMPCommon_1_1IConfigurationManagerProxy" ],
    [ "IError_v1", "classAdobeXMPCommon_1_1IError__v1.html", "classAdobeXMPCommon_1_1IError__v1" ],
    [ "IErrorNotifier_v1", "classAdobeXMPCommon_1_1IErrorNotifier__v1.html", "classAdobeXMPCommon_1_1IErrorNotifier__v1" ],
    [ "IMemoryAllocator_v1", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html", "classAdobeXMPCommon_1_1IMemoryAllocator__v1" ],
    [ "IObjectFactory_v1", "classAdobeXMPCommon_1_1IObjectFactory__v1.html", "classAdobeXMPCommon_1_1IObjectFactory__v1" ],
    [ "ISharedObject", "classAdobeXMPCommon_1_1ISharedObject.html", "classAdobeXMPCommon_1_1ISharedObject" ],
    [ "IThreadSafe", "classAdobeXMPCommon_1_1IThreadSafe.html", "classAdobeXMPCommon_1_1IThreadSafe" ],
    [ "IUTF8String_v1", "classAdobeXMPCommon_1_1IUTF8String__v1.html", "classAdobeXMPCommon_1_1IUTF8String__v1" ],
    [ "IVersionable", "classAdobeXMPCommon_1_1IVersionable.html", "classAdobeXMPCommon_1_1IVersionable" ],
    [ "ReportErrorAndContinueFunctor", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor.html", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor" ]
];