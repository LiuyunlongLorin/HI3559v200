var classAdobeXMPCommon_1_1IErrorNotifier__v1 =
[
    [ "Notify", "classAdobeXMPCommon_1_1IErrorNotifier__v1.html#ace4799050050f28ac3706b1de8940769", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IErrorNotifier__v1.html#a6b08a4aa1295fae50fe52c60787b3037", null ]
];