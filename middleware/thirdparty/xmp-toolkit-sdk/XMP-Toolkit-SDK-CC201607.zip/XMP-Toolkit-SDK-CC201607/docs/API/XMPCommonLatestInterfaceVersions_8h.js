var XMPCommonLatestInterfaceVersions_8h =
[
    [ "ICONFIGURABLE_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a829031e337c57225307b0be2d229a8b4", null ],
    [ "ICONFIGURATIONMANAGER_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a21492cbe0c77bbbad967232b377855c1", null ],
    [ "IERROR_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a4d8312c0c69be3f57e5f14b7b2d1224d", null ],
    [ "IERRORNOTIFIER_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#ad84704e1c2910ca9d71d41183c3a378c", null ],
    [ "IMEMORYALLOCATOR_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a5c5712b51cebbbdbf40cc691b4123209", null ],
    [ "IOBJECTFACTORY_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a6844f2fb727f99e352e61045154eba8b", null ],
    [ "IUTF8STRING_VERSION", "XMPCommonLatestInterfaceVersions_8h.html#a884c112243a29a7b0388b1954efc317b", null ]
];