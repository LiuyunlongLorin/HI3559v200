var structXMP__DateTime =
[
    [ "day", "structXMP__DateTime.html#a58496718277eea9dc5e3e19d80a69094", null ],
    [ "hasDate", "structXMP__DateTime.html#a62e0f39edef2a82749feed46b16572e8", null ],
    [ "hasTime", "structXMP__DateTime.html#a2c7f3d493a78f6b3fc7978992308d268", null ],
    [ "hasTimeZone", "structXMP__DateTime.html#a1dd34cdab96f55c120b3289db32bdd1e", null ],
    [ "hour", "structXMP__DateTime.html#abc79cdca8cfa5df6583279e3f3e70e9f", null ],
    [ "minute", "structXMP__DateTime.html#ae84965f3296a9c106d1f6c88aa6a7bdf", null ],
    [ "month", "structXMP__DateTime.html#ab4b71c1a54879d7da1b4135e23d5446f", null ],
    [ "nanoSecond", "structXMP__DateTime.html#a190c2a19f01e90997ec2973aec37712c", null ],
    [ "second", "structXMP__DateTime.html#a675313c70a7e05b7ca50d21300b7d81b", null ],
    [ "tzHour", "structXMP__DateTime.html#a6045133feeef41ac1f78c4664ab13db4", null ],
    [ "tzMinute", "structXMP__DateTime.html#a45baa70f30a3dc9f88819886cfb91aa1", null ],
    [ "tzSign", "structXMP__DateTime.html#a2b26282b9f1ab9920a8f05008c776ddb", null ],
    [ "year", "structXMP__DateTime.html#a2db713deacfd5a5cb2deea660ca2ccad", null ]
];