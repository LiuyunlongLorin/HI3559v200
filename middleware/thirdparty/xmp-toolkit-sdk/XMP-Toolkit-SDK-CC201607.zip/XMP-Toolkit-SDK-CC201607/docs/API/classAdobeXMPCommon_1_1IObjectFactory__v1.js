var classAdobeXMPCommon_1_1IObjectFactory__v1 =
[
    [ "~IObjectFactory_v1", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#a95fcbab435329d052ab42028da563c02", null ],
    [ "CreateError", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#ae86e711336af91dca23f4611b1f03724", null ],
    [ "CreateUTF8String", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#ae3e9eb977c305e48425654bec514f405", null ],
    [ "GetInterfaceID", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#ab61b0ddca88dc76f0499d317f189b918", null ],
    [ "GetInterfaceVersion", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#a81c25d76569a9249ab3c8a3e4490c73d", null ],
    [ "MakeObjectFactory", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#a2dc282621cdfef44b424ac91efb965a1", null ],
    [ "MakeObjectFactory", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#aa906cf2b9efb958e49fd8c5122b8db96", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IObjectFactory__v1.html#a2f02bcd4eafa4d318197c39dd55d0957", null ]
];