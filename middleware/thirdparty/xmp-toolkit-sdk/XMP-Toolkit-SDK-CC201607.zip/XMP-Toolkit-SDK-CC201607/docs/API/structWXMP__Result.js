var structWXMP__Result =
[
    [ "WXMP_Result", "structWXMP__Result.html#ad1046c86e2b3eba3109e6ae3f7063352", null ],
    [ "errMessage", "structWXMP__Result.html#ae329adc6d31243687d8bd85987ad6999", null ],
    [ "floatResult", "structWXMP__Result.html#a872bf8583413190b991beda67f017fb5", null ],
    [ "int32Result", "structWXMP__Result.html#a0bef8219ee23d2869ae6701330820794", null ],
    [ "int64Result", "structWXMP__Result.html#af515f52630be278a2334d7d9db587f13", null ],
    [ "ptrResult", "structWXMP__Result.html#ae1b91c50cee342a87f7708dd92a3d538", null ]
];