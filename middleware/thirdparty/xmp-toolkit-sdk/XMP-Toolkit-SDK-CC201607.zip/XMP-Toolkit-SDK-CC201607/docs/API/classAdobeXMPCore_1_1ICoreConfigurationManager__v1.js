var classAdobeXMPCore_1_1ICoreConfigurationManager__v1 =
[
    [ "~ICoreConfigurationManager_v1", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1.html#a16df3adfe25d46e47db70e02c1b8afd3", null ],
    [ "GetCoreConfigurationManager", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1.html#a867de0412ef1c6baf40a35714edd3f9e", null ]
];