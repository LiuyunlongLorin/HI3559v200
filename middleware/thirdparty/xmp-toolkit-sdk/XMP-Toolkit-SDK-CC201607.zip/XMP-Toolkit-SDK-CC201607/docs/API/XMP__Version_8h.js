var XMP__Version_8h =
[
    [ "XMPCORE_API_VERSION", "XMP__Version_8h.html#ac041954a884c9a67412ce45fd8b93ba8", null ],
    [ "XMPCORE_API_VERSION_MAJOR", "XMP__Version_8h.html#aac716764f5886d3aa2cae548de31914d", null ],
    [ "XMPCORE_API_VERSION_MICRO", "XMP__Version_8h.html#a23b73225c458457027b81af90253a36d", null ],
    [ "XMPCORE_API_VERSION_MINOR", "XMP__Version_8h.html#a9c0c98c086845899204c31cd7e40ee66", null ],
    [ "XMPCORE_API_VERSION_STRING", "XMP__Version_8h.html#a980a28c05c998865f032cda8057530dd", null ],
    [ "XMPFILES_API_VERSION", "XMP__Version_8h.html#ad887c030e319e8ec87b2bb219b411eba", null ],
    [ "XMPFILES_API_VERSION_MAJOR", "XMP__Version_8h.html#a2d20bc110f01b87d6456f9db1169d0f2", null ],
    [ "XMPFILES_API_VERSION_MICRO", "XMP__Version_8h.html#ab50f056612c375f3f3ec2c2bd4b15c20", null ],
    [ "XMPFILES_API_VERSION_MINOR", "XMP__Version_8h.html#a824cb65b80a8e7a2a434e3c7e90e34c1", null ],
    [ "XMPFILES_API_VERSION_STRING", "XMP__Version_8h.html#a76ec48e8c62eb491e18c98b620d83826", null ]
];