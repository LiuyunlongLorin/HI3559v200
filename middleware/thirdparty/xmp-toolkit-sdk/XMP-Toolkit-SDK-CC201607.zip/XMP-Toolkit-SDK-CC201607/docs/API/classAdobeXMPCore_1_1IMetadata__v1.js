var classAdobeXMPCore_1_1IMetadata__v1 =
[
    [ "~IMetadata_v1", "classAdobeXMPCore_1_1IMetadata__v1.html#ada50f9f0415ce96ac1df948f510a3f75", null ],
    [ "CreateMetadata", "classAdobeXMPCore_1_1IMetadata__v1.html#a114ea75cdd7e1101455af000e01ab17d", null ],
    [ "DisableFeature", "classAdobeXMPCore_1_1IMetadata__v1.html#a451bb5293ea38730bee99853b1d3237b", null ],
    [ "EnableFeature", "classAdobeXMPCore_1_1IMetadata__v1.html#a179a82bd3f38996331e9ee0bdee997b9", null ],
    [ "GetAboutURI", "classAdobeXMPCore_1_1IMetadata__v1.html#a707b78542a91b833a6cf45be3516813c", null ],
    [ "SetAboutURI", "classAdobeXMPCore_1_1IMetadata__v1.html#a275726ca1831735fff14119b224f1028", null ]
];