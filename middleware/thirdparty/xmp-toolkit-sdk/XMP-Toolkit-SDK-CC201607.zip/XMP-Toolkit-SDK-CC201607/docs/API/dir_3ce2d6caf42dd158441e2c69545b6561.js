var dir_3ce2d6caf42dd158441e2c69545b6561 =
[
    [ "IConfigurable.h", "IConfigurable_8h.html", [
      [ "IConfigurable", "classAdobeXMPCommon_1_1IConfigurable.html", "classAdobeXMPCommon_1_1IConfigurable" ],
      [ "CombinedDataValue", "unionAdobeXMPCommon_1_1IConfigurable_1_1CombinedDataValue.html", "unionAdobeXMPCommon_1_1IConfigurable_1_1CombinedDataValue" ]
    ] ],
    [ "ISharedObject.h", "ISharedObject_8h.html", [
      [ "ISharedObject", "classAdobeXMPCommon_1_1ISharedObject.html", "classAdobeXMPCommon_1_1ISharedObject" ]
    ] ],
    [ "IThreadSafe.h", "IThreadSafe_8h.html", [
      [ "IThreadSafe", "classAdobeXMPCommon_1_1IThreadSafe.html", "classAdobeXMPCommon_1_1IThreadSafe" ]
    ] ],
    [ "IVersionable.h", "IVersionable_8h.html", [
      [ "IVersionable", "classAdobeXMPCommon_1_1IVersionable.html", "classAdobeXMPCommon_1_1IVersionable" ]
    ] ]
];