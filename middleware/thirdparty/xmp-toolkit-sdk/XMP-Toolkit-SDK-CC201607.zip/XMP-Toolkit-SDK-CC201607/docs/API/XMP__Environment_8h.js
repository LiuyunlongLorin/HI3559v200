var XMP__Environment_8h =
[
    [ "DISABLE_SERIALIZED_IMPORT_EXPORT", "XMP__Environment_8h.html#a6bdd4740fca953d5f1722643d9295634", null ],
    [ "XMP_64", "XMP__Environment_8h.html#a69ebf613b248c1e76ae5dbdeee505881", null ],
    [ "XMP_DebugBuild", "XMP__Environment_8h.html#abeb16d5e16e7b2120731acb63ad88e9f", null ],
    [ "XMP_PRIVATE", "XMP__Environment_8h.html#a917e8e3f02685ec390fa3aee270f7747", null ],
    [ "XMP_PUBLIC", "XMP__Environment_8h.html#aac6a4810b1f485f147ab833be63f4d7b", null ]
];