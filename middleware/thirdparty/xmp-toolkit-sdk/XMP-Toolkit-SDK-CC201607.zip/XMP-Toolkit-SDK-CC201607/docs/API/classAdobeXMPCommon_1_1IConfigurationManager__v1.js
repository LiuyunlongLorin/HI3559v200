var classAdobeXMPCommon_1_1IConfigurationManager__v1 =
[
    [ "~IConfigurationManager_v1", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#aab2f368cf6883a6cd92fe688a95516b5", null ],
    [ "DisableMultiThreading", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#acf69fdd4ec5c1eb47b6a41b052372504", null ],
    [ "IsMultiThreaded", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#a32c1e2b6af5182d30d298be95652a065", null ],
    [ "RegisterErrorNotifier", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#af078935e322f611a884061977d015d1d", null ],
    [ "RegisterMemoryAllocator", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#a4886e0ac409969583acccbe344489a85", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html#ad857109e294bdff85685fa0974020645", null ]
];