var XMPCoreLatestInterfaceVersions_8h =
[
    [ "IARRAYNODE_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a1f8464a97acb8671e6cc2a466955d45d", null ],
    [ "ICLIENTDOMPARSER_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a64636b4e59a6212968ad30494675603e", null ],
    [ "ICLIENTDOMSERIALIZER_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#aa928953eda71cda88699483e1fca4526", null ],
    [ "ICOMPOSITENODE_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#aefe5b8d014bd0f2ca4933a16572b51df", null ],
    [ "ICORECONFIGURATIONMANAGER_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#adf7818c7264e7a80b1b3c5a5b283c47c", null ],
    [ "ICOREOBJECTFACTORY_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a3d28ba37018741b3794789e5edc6e27e", null ],
    [ "IDOMIMPLEMENTATIONREGISTRY_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#aa34dc59f9267eceb6d51235cd778292e", null ],
    [ "IDOMPARSER_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a813f82b55a0bb68c1553e8b38592e705", null ],
    [ "IDOMSERIALIZER_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a52d6e44f27f19214b38959683d6cc829", null ],
    [ "IMETADATA_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#af7d51c3ccf825fc82fa4a2a6cca26bc8", null ],
    [ "INAMESPACEPREFIXMAP_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a79e1c8ec2c46a2cbee3ba9cfd0d78ad4", null ],
    [ "INODE_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#aff2b1eabe2ac90a68ba3690930494a17", null ],
    [ "INODEITERATOR_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#afe7756c974951e8e78be1cfb96aacc8b", null ],
    [ "IPATH_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#adc9fb16e479a79e35a9dc58e166fcbad", null ],
    [ "IPATHSEGMENT_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a42cb9bdb3894ac77ff614349e5c371e5", null ],
    [ "ISIMPLENODE_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a799da65cf5811707628bb2681a4545ec", null ],
    [ "ISTRUCTURENODE_VERSION", "XMPCoreLatestInterfaceVersions_8h.html#a28325920d39a80ba79dd3774ce056f45", null ]
];