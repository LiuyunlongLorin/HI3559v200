var dir_8223d5ea7844a33492dce354418ea45e =
[
    [ "IArrayNode.h", "IArrayNode_8h.html", [
      [ "IArrayNode_v1", "classAdobeXMPCore_1_1IArrayNode__v1.html", "classAdobeXMPCore_1_1IArrayNode__v1" ]
    ] ],
    [ "IClientDOMParser.h", "IClientDOMParser_8h.html", [
      [ "IClientDOMParser_v1", "classAdobeXMPCore_1_1IClientDOMParser__v1.html", "classAdobeXMPCore_1_1IClientDOMParser__v1" ]
    ] ],
    [ "IClientDOMSerializer.h", "IClientDOMSerializer_8h.html", [
      [ "IClientDOMSerializer_v1", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html", "classAdobeXMPCore_1_1IClientDOMSerializer__v1" ]
    ] ],
    [ "ICompositeNode.h", "ICompositeNode_8h.html", [
      [ "ICompositeNode_v1", "classAdobeXMPCore_1_1ICompositeNode__v1.html", "classAdobeXMPCore_1_1ICompositeNode__v1" ]
    ] ],
    [ "ICoreConfigurationManager.h", "ICoreConfigurationManager_8h.html", [
      [ "ICoreConfigurationManager_v1", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1.html", "classAdobeXMPCore_1_1ICoreConfigurationManager__v1" ]
    ] ],
    [ "ICoreObjectFactory.h", "ICoreObjectFactory_8h.html", [
      [ "ICoreObjectFactory_v1", "classAdobeXMPCore_1_1ICoreObjectFactory__v1.html", "classAdobeXMPCore_1_1ICoreObjectFactory__v1" ]
    ] ],
    [ "IDOMImplementationRegistry.h", "IDOMImplementationRegistry_8h.html", [
      [ "IDOMImplementationRegistry_v1", "classAdobeXMPCore_1_1IDOMImplementationRegistry__v1.html", "classAdobeXMPCore_1_1IDOMImplementationRegistry__v1" ]
    ] ],
    [ "IDOMParser.h", "IDOMParser_8h.html", [
      [ "IDOMParser_v1", "classAdobeXMPCore_1_1IDOMParser__v1.html", "classAdobeXMPCore_1_1IDOMParser__v1" ]
    ] ],
    [ "IDOMSerializer.h", "IDOMSerializer_8h.html", [
      [ "IDOMSerializer_v1", "classAdobeXMPCore_1_1IDOMSerializer__v1.html", "classAdobeXMPCore_1_1IDOMSerializer__v1" ]
    ] ],
    [ "IMetadata.h", "IMetadata_8h.html", [
      [ "IMetadata_v1", "classAdobeXMPCore_1_1IMetadata__v1.html", "classAdobeXMPCore_1_1IMetadata__v1" ]
    ] ],
    [ "INameSpacePrefixMap.h", "INameSpacePrefixMap_8h.html", [
      [ "INameSpacePrefixMap_v1", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1" ]
    ] ],
    [ "INode.h", "INode_8h.html", [
      [ "INode_v1", "classAdobeXMPCore_1_1INode__v1.html", "classAdobeXMPCore_1_1INode__v1" ]
    ] ],
    [ "INodeIterator.h", "INodeIterator_8h.html", [
      [ "INodeIterator_v1", "classAdobeXMPCore_1_1INodeIterator__v1.html", "classAdobeXMPCore_1_1INodeIterator__v1" ]
    ] ],
    [ "IPath.h", "IPath_8h.html", [
      [ "IPath_v1", "classAdobeXMPCore_1_1IPath__v1.html", "classAdobeXMPCore_1_1IPath__v1" ]
    ] ],
    [ "IPathSegment.h", "IPathSegment_8h.html", [
      [ "IPathSegment_v1", "classAdobeXMPCore_1_1IPathSegment__v1.html", "classAdobeXMPCore_1_1IPathSegment__v1" ]
    ] ],
    [ "ISimpleNode.h", "ISimpleNode_8h.html", [
      [ "ISimpleNode_v1", "classAdobeXMPCore_1_1ISimpleNode__v1.html", "classAdobeXMPCore_1_1ISimpleNode__v1" ]
    ] ],
    [ "IStructureNode.h", "IStructureNode_8h.html", [
      [ "IStructureNode_v1", "classAdobeXMPCore_1_1IStructureNode__v1.html", "classAdobeXMPCore_1_1IStructureNode__v1" ]
    ] ]
];