var classAdobeXMPCommon_1_1IThreadSafe =
[
    [ "DisableThreadSafety", "classAdobeXMPCommon_1_1IThreadSafe.html#a214bb1b5840dbd5576e764dd2220b261", null ],
    [ "EnableThreadSafety", "classAdobeXMPCommon_1_1IThreadSafe.html#afe35614cb88e2bdb32996cf4ac15b211", null ],
    [ "IsThreadSafe", "classAdobeXMPCommon_1_1IThreadSafe.html#a261e2f6af96b75015e5f8318f32be7f9", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IThreadSafe.html#a0f31eb9677c4af06288319e363c21ebc", null ]
];