var dir_0fb2101ba02d68f078970216a1fe0334 =
[
    [ "client-glue", "dir_0e5f10c8914b73a2f667b010a9332417.html", "dir_0e5f10c8914b73a2f667b010a9332417" ],
    [ "XMPCommon", "dir_13a16c6fe91841c884a316194c73d6c1.html", "dir_13a16c6fe91841c884a316194c73d6c1" ],
    [ "XMPCore", "dir_d9f2167f9fcfc7d7593f67aa31e893fd.html", "dir_d9f2167f9fcfc7d7593f67aa31e893fd" ],
    [ "TXMPFiles.hpp", "TXMPFiles_8hpp.html", [
      [ "TXMPFiles", "classTXMPFiles.html", "classTXMPFiles" ]
    ] ],
    [ "TXMPIterator.hpp", "TXMPIterator_8hpp.html", [
      [ "TXMPIterator", "classTXMPIterator.html", "classTXMPIterator" ]
    ] ],
    [ "TXMPMeta.hpp", "TXMPMeta_8hpp.html", [
      [ "TXMPIterator", "classTXMPIterator.html", "classTXMPIterator" ],
      [ "TXMPUtils", "classTXMPUtils.html", "classTXMPUtils" ],
      [ "TXMPMeta", "classTXMPMeta.html", "classTXMPMeta" ]
    ] ],
    [ "TXMPUtils.hpp", "TXMPUtils_8hpp.html", [
      [ "TXMPUtils", "classTXMPUtils.html", "classTXMPUtils" ]
    ] ],
    [ "XMP.hpp", "XMP_8hpp.html", null ],
    [ "XMP_Const.h", "XMP__Const_8h.html", "XMP__Const_8h" ],
    [ "XMP_Environment.h", "XMP__Environment_8h.html", "XMP__Environment_8h" ],
    [ "XMP_IO.hpp", "XMP__IO_8hpp.html", [
      [ "XMP_IO", "classXMP__IO.html", "classXMP__IO" ]
    ] ],
    [ "XMP_Version.h", "XMP__Version_8h.html", "XMP__Version_8h" ]
];