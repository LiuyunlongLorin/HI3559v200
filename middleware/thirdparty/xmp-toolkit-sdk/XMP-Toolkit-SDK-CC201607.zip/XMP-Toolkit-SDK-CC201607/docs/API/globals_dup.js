var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "i", "globals_i.html", null ],
    [ "j", "globals_j.html", null ],
    [ "k", "globals_k.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "q", "globals_q.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "w", "globals_w.html", null ],
    [ "x", "globals_x.html", null ],
    [ "z", "globals_z.html", null ]
];