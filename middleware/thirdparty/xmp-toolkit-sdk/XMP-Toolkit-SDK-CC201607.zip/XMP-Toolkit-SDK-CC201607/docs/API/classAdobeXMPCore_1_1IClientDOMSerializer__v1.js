var classAdobeXMPCore_1_1IClientDOMSerializer__v1 =
[
    [ "~IClientDOMSerializer_v1", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#a58ff533c49dcfcf3374097aea70c1107", null ],
    [ "AreKeysCaseSensitive", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#aa6090a60c51266963005c2fce33ea760", null ],
    [ "Initialize", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#a370646890f776a587f0faff20d590059", null ],
    [ "Release", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#a513bdaeb37f453787f46a5e855ac08ef", null ],
    [ "Serialize", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#a604822b9cacd9b1ebaba08e49513f778", null ],
    [ "Validate", "classAdobeXMPCore_1_1IClientDOMSerializer__v1.html#a5bcaa25de727ee1e8e9399dd963aa5c3", null ]
];