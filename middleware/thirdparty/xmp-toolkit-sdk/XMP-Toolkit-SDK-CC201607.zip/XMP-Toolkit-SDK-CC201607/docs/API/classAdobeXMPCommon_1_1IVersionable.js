var classAdobeXMPCommon_1_1IVersionable =
[
    [ "~IVersionable", "classAdobeXMPCommon_1_1IVersionable.html#a3ccd9a1bdf7008906e094fb4e7f69826", null ],
    [ "GetInterfacePointer", "classAdobeXMPCommon_1_1IVersionable.html#ad6539461695decfaea8a44798db51e54", null ],
    [ "GetInterfacePointer", "classAdobeXMPCommon_1_1IVersionable.html#ab93a940e2946c14a76ebbd9552cab070", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IVersionable.html#ac619a81b428c88cfce50feaa91a2479f", null ]
];