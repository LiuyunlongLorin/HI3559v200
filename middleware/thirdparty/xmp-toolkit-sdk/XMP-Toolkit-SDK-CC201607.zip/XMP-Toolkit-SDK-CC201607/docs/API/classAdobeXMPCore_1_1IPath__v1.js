var classAdobeXMPCore_1_1IPath__v1 =
[
    [ "~IPath_v1", "classAdobeXMPCore_1_1IPath__v1.html#ad2d1a79e6c8e270c1cb9acee09e7881e", null ],
    [ "AppendPathSegment", "classAdobeXMPCore_1_1IPath__v1.html#ad11a65bed658401f8cfcd41387e2b8a6", null ],
    [ "Clear", "classAdobeXMPCore_1_1IPath__v1.html#af056942f9dba913762b258cb5b422300", null ],
    [ "Clone", "classAdobeXMPCore_1_1IPath__v1.html#a054e7cb641a72c7d3e7f35ef1225c6f4", null ],
    [ "CreatePath", "classAdobeXMPCore_1_1IPath__v1.html#a0da106657f48b1c8859e31de357015d4", null ],
    [ "GetPathSegment", "classAdobeXMPCore_1_1IPath__v1.html#a7c7c78fcf2aac3af21c3803cb72b0afc", null ],
    [ "IsEmpty", "classAdobeXMPCore_1_1IPath__v1.html#ac6b2215fb0cf7e14d96915bcbdd6d5c8", null ],
    [ "ParsePath", "classAdobeXMPCore_1_1IPath__v1.html#a64165b6024ea00ea1cc1c13bd6708a44", null ],
    [ "RegisterNameSpacePrefixMap", "classAdobeXMPCore_1_1IPath__v1.html#a75c08c101e11f3059d7bff2fde6e6817", null ],
    [ "RemovePathSegment", "classAdobeXMPCore_1_1IPath__v1.html#a7de20abb4af96e274ef5476a1e718d77", null ],
    [ "Serialize", "classAdobeXMPCore_1_1IPath__v1.html#ad5920be57f3243c5601ad214e3b1e0c1", null ],
    [ "Size", "classAdobeXMPCore_1_1IPath__v1.html#a6a0bc65d535aabdfd52608b29270c558", null ]
];