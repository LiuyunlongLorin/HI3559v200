var classAdobeXMPCore_1_1IStructureNode__v1 =
[
    [ "~IStructureNode_v1", "classAdobeXMPCore_1_1IStructureNode__v1.html#a0cdcce18c6ebbb1764286e3e2456c694", null ],
    [ "CreateStructureNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#ab39f8d743ba67fc4e6a21b08b03fdde2", null ],
    [ "GetArrayNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a8ee43418308bf6f80d1fc90eb84f5db0", null ],
    [ "GetArrayNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#af8fe4c8e7c9a5262b1125aea6606fe2e", null ],
    [ "GetChildNodeType", "classAdobeXMPCore_1_1IStructureNode__v1.html#a1463dda9dea83f54c69ad72f105f5eff", null ],
    [ "GetNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#afd94de430e29982143eb04315b954b24", null ],
    [ "GetNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#af5ce2401c3613c06ccb8b8fa69af4a1c", null ],
    [ "GetSimpleNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#aaf000a83b1448eb8453f37fc42543ae7", null ],
    [ "GetSimpleNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a23ea406052e9201f3b35e59cc2b206a5", null ],
    [ "GetStructureNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#ab815d3b2335f27dccc15472196696e08", null ],
    [ "GetStructureNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a9b380e96dca941b5f9c3143931f7f633", null ],
    [ "InsertNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a22d61015856c67f05237af9513e98ff7", null ],
    [ "RemoveNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a25d8ec1ee8031cb693bb8c8a8102c8f8", null ],
    [ "ReplaceNode", "classAdobeXMPCore_1_1IStructureNode__v1.html#a5764457c137c97a42af6ca156563e455", null ]
];