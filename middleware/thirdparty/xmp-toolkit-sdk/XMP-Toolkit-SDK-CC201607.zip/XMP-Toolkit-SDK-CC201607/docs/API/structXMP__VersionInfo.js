var structXMP__VersionInfo =
[
    [ "build", "structXMP__VersionInfo.html#a0e20a6bf10da4c17bdfc8027f1586ffc", null ],
    [ "flags", "structXMP__VersionInfo.html#ad018f35b382046ca77b1252bafa93f74", null ],
    [ "isDebug", "structXMP__VersionInfo.html#af1643d86f32f5a5a275dc9c5ba843018", null ],
    [ "major", "structXMP__VersionInfo.html#a7edfa1613a58a248fd15267008bd8afb", null ],
    [ "message", "structXMP__VersionInfo.html#a19654242b92bffd7517e92882850e834", null ],
    [ "micro", "structXMP__VersionInfo.html#a4b448a8253e26a37d2df35e04ac25d28", null ],
    [ "minor", "structXMP__VersionInfo.html#af5b56598e15febd742b431dadae7c317", null ]
];