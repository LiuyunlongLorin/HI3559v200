var classAdobeXMPCommon_1_1ISharedObject =
[
    [ "~ISharedObject", "classAdobeXMPCommon_1_1ISharedObject.html#a5869ff89d0b7dd0a7b525401a1d57b31", null ],
    [ "Acquire", "classAdobeXMPCommon_1_1ISharedObject.html#ab90d4ec1fcd975a7ac62dcb866335cdc", null ],
    [ "Release", "classAdobeXMPCommon_1_1ISharedObject.html#abf5a54e09f87366170ea19c618f68bc3", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1ISharedObject.html#afcb42109aed83c3b0c133bc413388037", null ]
];