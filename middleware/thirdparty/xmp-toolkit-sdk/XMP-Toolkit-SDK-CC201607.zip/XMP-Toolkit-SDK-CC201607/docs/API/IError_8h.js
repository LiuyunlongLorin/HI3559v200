var IError_8h =
[
    [ "IError_v1", "classAdobeXMPCommon_1_1IError__v1.html", "classAdobeXMPCommon_1_1IError__v1" ],
    [ "ReportErrorAndContinueFunctor", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor.html", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor" ],
    [ "ReportErrorAndContinueABISafeProc", "IError_8h.html#a8dc9ba4ce78a957c0843998c2468241a", null ]
];