var classXMP__Error =
[
    [ "XMP_Error", "classXMP__Error.html#aa8b3b859899759d679b00237254e30aa", null ],
    [ "GetErrMsg", "classXMP__Error.html#a9a3560c67612dec9a6ca37c34eb2c153", null ],
    [ "GetID", "classXMP__Error.html#a56aaa6fc6644ccfc9470ae1af8f3a8cd", null ],
    [ "IsNotified", "classXMP__Error.html#a5a0651a9615a6a60e467a96ddb43a6bb", null ],
    [ "SetNotified", "classXMP__Error.html#a9c368db94ca63ad7b9b118051d1f8897", null ],
    [ "errMsg", "classXMP__Error.html#a31fd80098e50026985e05abd16f3e045", null ],
    [ "id", "classXMP__Error.html#aad714bd7c428e10eff07a8ab6a4f3125", null ],
    [ "notified", "classXMP__Error.html#a2b884dfb0b39689d1cf95105eadc4571", null ]
];