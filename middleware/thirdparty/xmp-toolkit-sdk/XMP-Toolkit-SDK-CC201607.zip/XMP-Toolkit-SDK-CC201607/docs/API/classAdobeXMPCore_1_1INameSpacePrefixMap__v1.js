var classAdobeXMPCore_1_1INameSpacePrefixMap__v1 =
[
    [ "~INameSpacePrefixMap_v1", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#aabfdffd2a782e83a627bbe1c687a922b", null ],
    [ "Clear", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a6ed5fd946dfad6406539562178b3caeb", null ],
    [ "Clone", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#ae30d56519a24afe9c22ae353fedbd8f7", null ],
    [ "CreateNameSpacePrefixMap", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a722b12c77879087c26990650d99d3339", null ],
    [ "GetDefaultNameSpacePrefixMap", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a16669cda8f88d9af18a248919103df22", null ],
    [ "GetNameSpace", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a57a2ef1d7b5f9fb2429220becad03413", null ],
    [ "GetPrefix", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a5a6915e1bdfa1059f4ad690bcf14a342", null ],
    [ "Insert", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a1cff14bbc35fabd9fff60706ebfe23e8", null ],
    [ "IsEmpty", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a4ba4127d58b778c0148f853d7a60b8fe", null ],
    [ "IsNameSpacePresent", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#ab6fe5421aa97518a85e87bba9f4bc3a6", null ],
    [ "IsPrefixPresent", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a10caae18d32483ff4a5737c448f4f7c3", null ],
    [ "RemoveNameSpace", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#ab030c648e112799541eb3433967207c7", null ],
    [ "RemovePrefix", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#aa4575950788bfa70dee5fad2d851230e", null ],
    [ "Size", "classAdobeXMPCore_1_1INameSpacePrefixMap__v1.html#a3dfd0d265952656c9b6641d8ce523e40", null ]
];