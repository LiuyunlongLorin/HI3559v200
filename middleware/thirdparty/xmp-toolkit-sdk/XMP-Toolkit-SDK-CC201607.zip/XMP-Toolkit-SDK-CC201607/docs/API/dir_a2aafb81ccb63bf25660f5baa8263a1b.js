var dir_a2aafb81ccb63bf25660f5baa8263a1b =
[
    [ "BaseInterfaces", "dir_3ce2d6caf42dd158441e2c69545b6561.html", "dir_3ce2d6caf42dd158441e2c69545b6561" ],
    [ "IConfigurationManager.h", "IConfigurationManager_8h.html", [
      [ "IConfigurationManager_v1", "classAdobeXMPCommon_1_1IConfigurationManager__v1.html", "classAdobeXMPCommon_1_1IConfigurationManager__v1" ],
      [ "IConfigurationManagerProxy", "classAdobeXMPCommon_1_1IConfigurationManagerProxy.html", "classAdobeXMPCommon_1_1IConfigurationManagerProxy" ]
    ] ],
    [ "IError.h", "IError_8h.html", "IError_8h" ],
    [ "IErrorNotifier.h", "IErrorNotifier_8h.html", [
      [ "IErrorNotifier_v1", "classAdobeXMPCommon_1_1IErrorNotifier__v1.html", "classAdobeXMPCommon_1_1IErrorNotifier__v1" ]
    ] ],
    [ "IMemoryAllocator.h", "IMemoryAllocator_8h.html", [
      [ "IMemoryAllocator_v1", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html", "classAdobeXMPCommon_1_1IMemoryAllocator__v1" ]
    ] ],
    [ "IObjectFactory.h", "IObjectFactory_8h.html", [
      [ "IObjectFactory_v1", "classAdobeXMPCommon_1_1IObjectFactory__v1.html", "classAdobeXMPCommon_1_1IObjectFactory__v1" ]
    ] ],
    [ "IUTF8String.h", "IUTF8String_8h.html", [
      [ "IUTF8String_v1", "classAdobeXMPCommon_1_1IUTF8String__v1.html", "classAdobeXMPCommon_1_1IUTF8String__v1" ]
    ] ]
];