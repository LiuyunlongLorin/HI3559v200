var classAdobeXMPCommon_1_1IMemoryAllocator__v1 =
[
    [ "allocate", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html#a2942e9d8f0d685ae6ebe58c18a11b999", null ],
    [ "deallocate", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html#a607755ef64bf552482c4a330fcc79120", null ],
    [ "reallocate", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html#a89ea55ddb2e5a544a93525b227b042f9", null ],
    [ "REQ_FRIEND_CLASS_DECLARATION", "classAdobeXMPCommon_1_1IMemoryAllocator__v1.html#aee52f392f1548bffc01b2be3fd9fab28", null ]
];