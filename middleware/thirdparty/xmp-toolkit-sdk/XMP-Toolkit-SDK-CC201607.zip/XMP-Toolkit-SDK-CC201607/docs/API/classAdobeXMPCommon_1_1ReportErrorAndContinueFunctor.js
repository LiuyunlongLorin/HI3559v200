var classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor =
[
    [ "ReportErrorAndContinueFunctor", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor.html#a40e6fedd9a880d70095b9468b5cf05db", null ],
    [ "operator()", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor.html#a5dd060eac19acba07ce701dc9ebaa09d", null ],
    [ "mSafeProc", "classAdobeXMPCommon_1_1ReportErrorAndContinueFunctor.html#a3b28d2e68ebbcd5d20781d8b7a48f879", null ]
];