var classAdobeXMPCore_1_1IDOMSerializer__v1 =
[
    [ "~IDOMSerializer_v1", "classAdobeXMPCore_1_1IDOMSerializer__v1.html#a3631ef4b5bf7814d37f9582463d7d453", null ],
    [ "Clone", "classAdobeXMPCore_1_1IDOMSerializer__v1.html#a4b8a7832e2dbbadfaed717723d3d20d3", null ],
    [ "Serialize", "classAdobeXMPCore_1_1IDOMSerializer__v1.html#ac8e65d9aed0a6afc951e075178d81338", null ]
];