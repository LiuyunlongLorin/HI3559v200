/**
 * \cond skip
 * vim:syntax=doxygen
 * \endcond

\page genl_doc Generic Netlink Library (-lnl-genl)

\section genl_intro Introduction

*/
