/**
 * \cond skip
 * vim:syntax=doxygen
 * \endcond

\page route_doc Routing Netlink Library (-lnl-route)

\section route_intro Introduction

*/
