#include "sim-basics.h"
#include "sim-signal.h"

typedef unsigned32 sim_cia;

#include "sim-base.h"

struct sim_state {
  sim_state_base base;
};
