#include "bf50x-0.0.h"

#include "bf51x-0.0.h"
#include "bf51x-0.1.h"
#include "bf51x-0.2.h"

#include "bf526-0.0.h"
#include "bf526-0.1.h"
#include "bf526-0.2.h"
#include "bf527-0.0.h"
#include "bf527-0.1.h"
#include "bf527-0.2.h"

#include "bf533-0.1.h"
#include "bf533-0.2.h"
#include "bf533-0.3.h"
#define bfrom_bf533_0_4 bfrom_bf533_0_3
#define bfrom_bf533_0_5 bfrom_bf533_0_3
#define bfrom_bf533_0_6 bfrom_bf533_0_3

#include "bf537-0.0.h"
#include "bf537-0.1.h"
#define bfrom_bf537_0_2 bfrom_bf537_0_1
#include "bf537-0.3.h"

#include "bf538-0.0.h"
#define bfrom_bf538_0_1 bfrom_bf538_0_0
#define bfrom_bf538_0_2 bfrom_bf538_0_0
#define bfrom_bf538_0_3 bfrom_bf538_0_0
#define bfrom_bf538_0_4 bfrom_bf538_0_0
#define bfrom_bf538_0_5 bfrom_bf538_0_0

#include "bf54x-0.0.h"
#include "bf54x-0.1.h"
#include "bf54x-0.2.h"
#include "bf54x-0.4.h"
#include "bf54x_l1-0.0.h"
#include "bf54x_l1-0.1.h"
#include "bf54x_l1-0.2.h"
#include "bf54x_l1-0.4.h"

#include "bf561-0.5.h"

#include "bf59x-0.0.h"
#define bfrom_bf59x_0_1 bfrom_bf59x_0_0
#include "bf59x_l1-0.1.h"
